﻿using System.Windows;

namespace DocumentEditor
{
    internal sealed partial class App : Application
    {
    }
}