#include "Building.h"

Building::~Building()
{
	cout << "~Biulding()" << endl;
}
