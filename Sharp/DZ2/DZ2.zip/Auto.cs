﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DZ2
{
    partial class Auto
    {
        public void Wroom()
        {
            Console.WriteLine("Wroom");
        }
    }
}
